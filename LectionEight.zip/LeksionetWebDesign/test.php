<?php
//Lection eight

$shpetim = 1;
$str = "Testing";

echo $shpetim." ".$str."<br>";
ECHO $shpetim." ".$str;
echo "<hr>";

$txt1 = "PHP course";
$x = 5;
$y = 6;

print "<h3>".$txt1."</h3>";
echo"<br>";
print $x + $y."<br>";

/* evidentimi i llojit te variablit */
$z = [59888, "56666", 6969, 123435];
var_dump($z);

echo "<hr>";

/* Krijimi i klases Car */
class Car {
  function carName(){
   return "Benz";
  }
  function carPrice(){
    $price = "200000$";
    return $price;
  }
}

/* Inicializimi i klases Car */
$makina = new Car();
echo $makina->carName()."<br>";
echo $makina->carPrice()."<br>";

/* ===== Kapja e elementit te fundit */
$el = 5;
$el = "numer tjeter";
echo $el;

/* ===== ciklet for ==== */
$array = ["Benz", "Golf", "Volvo"];

for($i=0; $i<sizeof($array); $i++){
    echo "<br>".$array[$i]."<br>";
}
echo "<hr>";
foreach($array as $key=>$ar){
     echo $key."->".$ar."<br>";
}


?>
