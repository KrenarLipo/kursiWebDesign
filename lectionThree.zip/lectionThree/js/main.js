/* ===== Lection two ===== */
var totali = "Hello World";
var mosha = 23;
var mosha2 = 25;
totali = mosha + mosha2;


function myFunction(){
	console.log(totali);
}

function kuJemi(){
	var text = document.getElementById("klikuar");
	console.log(text);
}

/* ===== Lection three ===== */

var arrayOne = [];
var testOne = 10;
arrayOne.push(testOne);
var testTwo = "I am a string";
arrayOne.push(testTwo);
console.log(arrayOne);


function gjejPershendetjen() {
  var greeting;
  var time = new Date().getHours();
  if (time < 10) {
    greeting = "Good morning";
  } else if (time < 20) {
    greeting = "Good day";
  } else {
    greeting = "Good evening";
  }
  document.getElementById("pershendetja").innerHTML = greeting;
}

function gjejDiten() {
	var day;
	switch (new Date().getDay()) {
	  case 0:
		day = "Sunday";
		break;
	  case 1:
		day = "Monday";
		break;
	  case 2:
		day = "Tuesday";
		break;
	  case 3:
		day = "Wednesday";
		break;
	  case 4:
		day = "Thursday";
		break;
	  case 5:
		day = "Friday";
		break;
	  case  6:
		day = "Saturday";
	}
	document.getElementById("dita").innerHTML = "Today is " + day;
}