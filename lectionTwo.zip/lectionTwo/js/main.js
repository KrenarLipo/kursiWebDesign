var totali = "Hello World";
var mosha = 23;
var mosha2 = 25;
totali = mosha + mosha2;


function myFunction(){
	console.log(totali);
}

function kuJemi(){
	var text = document.getElementById("klikuar");
	console.log(text);
}

