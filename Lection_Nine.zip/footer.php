			  <!-- Footer -->
			 <footer class="footer text-center">
				<div class="container">
				  <ul class="list-inline mb-5">
					<li class="list-inline-item">
					  <a href="#">
						<i class="fab fa-facebook-f"></i>
					  </a>
					</li>
					<li class="list-inline-item">
					  <a href="#">
						<i class="fab fa-twitter"></i>
					  </a>
					</li>
					<li class="list-inline-item">
					  <a href="#">
						<i class="fab fa-github"></i>
					  </a>
					</li>
				  </ul>
				  <p class="text-muted small mb-0">Copyright &copy; Your Website 2019</p>
				</div>
			 </footer>
		</div>
   

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded js-scroll-trigger" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Bootstrap core JavaScript -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/main.js"></script>
  <script>
	$('.carousel').carousel({
		interval: 5000
	});
  </script>

  <!-- Plugin JavaScript 
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>-->

  <!-- Custom scripts for this template
  <script src="js/stylish-portfolio.min.js"></script>-->

</body>

</html>