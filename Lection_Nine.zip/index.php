    <?php include 'header.php'; ?>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <a class="navbar-brand" href="#"><img src="img/logoja.png"></a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
    
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
            <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">About Us</a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="#portfolio">Portfolio</a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="#">Contact</a>
          </li>
         
        </ul>
        <form class="form-inline my-2 my-lg-0">
          <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-primary my-2 my-sm-0" type="submit">Search</button>
        </form>
      </div>
    </nav>
		<!-- Inicializimi i carouselit -->
        <header id="myCarousel" class="carousel slide" data-ride="carousel">
			<ol class="carousel-indicators">
				<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
				<li data-target="#myCarousel" data-slide-to="1"></li>
				<li data-target = "#myCarousel" data-slide-to="2"></li>
			</ol>
			
			<!-- permbajtesi i sliderit -->
			<div class="carousel-inner">
				<div class="carousel-item active">
				<!-- vendosim backgroundin e pare duke perdorur inline-css-->
				<div class="fill" style="background-image:url('http://placehold.it/1900x1080&text=Slide One');"></div>
					<div class="carousel-caption">
						<h2>Caption 1</h2>
					</div>
				</div>
				<div class="carousel-item">
					<!-- vendosim backgrundin e imazhit te dyte -->
					<div class="fill" style="background-image:url('http://placehold.it/1900x1080&text=Slide Two');"></div>
						<div class="carousel-caption">
							<h2>Caption 2</h2>
						</div>
				</div>
				<div class="carousel-item">
					<!-- vendosim backgrundin e imazhit te dyte -->
					<div class="fill" style="background-image:url('http://placehold.it/1900x1080&text=Slide Three');"></div>
						<div class="carousel-caption">
							<h2>Caption 3</h2>
						</div>
				</div>
				</div><!-- End Carosuel inner -->
				
				<!-- Shigjetat ndryshuese -->
				<a class="left carousel-control" href="#myCarousel" data-slide="prev">
					<i class="fas fa-arrow-left"></i>
				</a>
				<a class="right carousel-control" href="#myCarousel" data-slide="next">
					<i class="fas fa-arrow-right"></i>
				</a>
		</header>
    
    <!-- Sektori i containers poshte -->
    <div class="container">
        
        <!-- Grupi i pare i rows -->
        <div class="row">
		
            <div class="col-12 col-sm-6 col-md-4">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
                It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
                It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            </div>
            <div class="col-12 col-sm-6 col-md-4">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
                It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
                It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            </div>
            <div class="col-12 col-sm-6 col-md-4">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
                It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
                It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            </div>
        </div><!-- End grupi i pare i rows -->
        <br>
        <!-- Grupi i dyte i rows -->
        <div class="row" style="border:1px solid #000; padding:8%;">
            <div class="col-12 col-sm-6 col-md-4">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
                It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
                It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            </div>
            <div class="col-12 col-sm-6 col-md-4">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
                It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
                It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            </div>
            <div class="col-12 col-sm-6 col-md-4">
                Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
                Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
                It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. 
                It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.
            </div>
        </div><!-- End grupi i dyte i rows -->
		</div>
		
		<div class="container">
			<!-- grupi i efekteve me css -->
			<div id="portfolio" class="row" style="margin:10px 0; padding:0;">
				<div class="col-12 col-sm-6 col-md-4">
					<div class="img-hover-zoom">
						<img class="img-fluid" src="img/london-view.jpg">
					</div>
				</div>
				<div class="col-12 col-sm-6 col-md-4">
					<div class="img-hover-fastzoom">
						<img class="img-fluid" src="img/campus-tour.jpg">
					</div>
				</div>
				<div class="col-12 col-sm-6 col-md-4">
					<div class="img-hover-pointzoom">
						<img class="img-fluid" src="img/inthecascade.jpg">
					</div>
				</div>
				<div class="col-12 col-sm-6 col-md-4">
					<div class="img-hover-rotation">
						<img class="img-fluid" src="img/flowers.jpg">
					</div>
				</div>
				<div class="col-12 col-sm-6 col-md-4">
					<div class="img-hover-vertical-zoom">
						<img class="img-fluid" src="img/city-sunset.jpg">
					</div>
				</div>
				<div class="col-12 col-sm-6 col-md-4">
					<div class="img-hover-colorized">
						<img class="img-fluid" src="img/night-view-city.jpg">
					</div>
				</div>
			</div><!-- Fund grupi i trete i rows -->
			   <!-- Modal Section -->
				<div class="row" style="margin-top:10px;">
					<!-- Button trigger modal -->
					<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
					  Launch demo modal
					</button>
					<button style="margin-left:10px;" id="klikuar" onmouseover="kuJemi()" onclick="alert('klikim')" class="btn btn-success">Me kliko!</button>
					<button style="margin-left:10px;" onclick="gjejPershendetjen()" class="btn btn-primary">Gjej pershendetjen!</button>
					<button style="margin-left:10px;" onclick="getExactDate()" class="btn btn-info">Gjej diten!</button>
					<span style="padding-left:10px"><input id="age" placeholder="Kontrollo moshen" value=""/><button onclick="gjejMoshen()">A votoj?</button><p id="result"></p></span>
					<button style="margin-left:10px;" onclick="shfaqMakinat()" class="btn btn-warning listo">Listo makinat!</button>
				</div>
				<p id="pershendetja"></p>
				<p id="dita"></p>
				<p id="makinat"></p>
				<div class="row">
				<!-- Test hide funcinality -->
				<div class="col-12 col-sm-6 col-md-4" style="background:#c3c3c3; border:1px solid #000; padding:10px;">
					<p class="emerone">Emer one </p>
					<p>Emer two</p>
					
					<!-- Shfaqim makinat ne nje div nepermjet jquery -->
					<div class="makinatJquery"></div>
				</div>
				
				<div class="col-12 col-sm-6 col-md-4" style="background:#c1c1c1; border:1px solid #000; padding:10px;">
					<!-- Bashkepunimi midis dy elementeve -->
					<p class="pertufshehur">Higuain s'duhet te bente gol!</p>
					<button id="butoniFsheh">Fsheh text</button>
					<p class="butonShtese"></p>
				</div>
				
				
				  <div class="col-12 col-sm-6 col-md-4" style="background:#c4c4c4; border:1px solid #000; padding:10px;">
					<!-- Efekte te ndryshme me jquery -->
					<p>Demostrim fadeIn boxes</p>
					<button id="butoniKatror">Inicializo katroret</button>
					<div id="div1" 
						style="
						width:80px; 
						height:80px;
						display:none;
						background-color:red;">
					</div>
					<div id="div2" 
						style="
						width:80px; 
						height:80px;
						display:none;
						background-color:green;">
					</div>
					<div id="div3" 
						style="
						width:80px; 
						height:80px;
						display:none;
						background-color:blue;">
					</div>
				</div>	
				</div>	
		</div><!-- End container -->
		<div class="container">
			<div class="row">
				<div class="col-12 col-sm-12 col-md-5" style="margin-top:20px;">
					<button class="butoniKatror">Start Animation</button>
					<p>You will see some effects on the rectangle below!</p>
					<div class="greenRectangle katroriJeshil"></div>
				</div>
			    <div class="col-12 col-sm-4 col-md-4" style="background-color:#f4f4f4; margin-top:20px;">
					<div id="flip" class="col-12 col-sm-12 col-md-12">Click to slide down panel</div>
					<div id="panel" class="col-12 col-sm-12 col-md-12">Maratona e Tiranes</div>
				</div>
				<div class="col-12 col-sm-4 col-md-3" style="background-color:#f4f4f4; margin-top:20px;">
					<div class="col-12 col-sm-12 col-md-12">
						<h4>Change my color</h4>
						<input class="red" type="button" value="Ngjyros me te kuqe"/>
					</div>
				</div>
			</div>
		</div>
		
		<!-- Lection seven form validation -->
		<div class="clearfix"></div>
		<div class="container" style="margin-top:20px;">
			<div class="row">
				<div class="col-md-8">
					<h4>Left Side</h4>
					<form id="first_form" method="post" action="">
						<div>
							<label for="first_name">First Name</label>
							<input type="text" id="first_name" name="first_name"/>
						</div>
						<div>
							<label for="last_name">Last Name</label>
							<input type="text" id="last_name" name="last_name"/>
						</div>
						<div>
							<label for="email">Email</label>
							<input type="email" id="email" name="email" />
						</div>
						<div>
							<label for="password">Password</label>
							<input type="password" id="password" name="password" />
						</div>
						<div>
							<input type="submit" value="Submit" /> 
						</div>
					</form>
				</div>
				<div class="col-md-4">
					<h4>Right Side</h4>
						<?php 
						  function emerFunksioni(){
							  return "something";
						  }
		  
		                echo "<br>".emerFunksioni();
	                    ?>
				</div>
			</div>
		</div>
		
		<div class="clearfix"></div>
			<div class="container" style="margin-top:150px;">
			<!-- Modal -->
			<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			  <div class="modal-dialog" role="document">
				<div class="modal-content">
				  <div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					  <span aria-hidden="true">&times;</span>
					</button>
				  </div>
				  <div class="modal-body">
					Edhe per pak edhe largohemi
				  </div>
				  <div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Mbyll</button>
					<button onclick="myFunction()" id="butoniSave" type="button" class="btn btn-primary">Ruaj</button>
				  </div>
				</div>
			  </div>
			</div>
			</div>
			<?php include 'footer.php';?>
