/* ===== Lection two ===== */
var totali = "Hello World";
var mosha = 23;
var mosha2 = 25;
totali = mosha + mosha2;


function myFunction(){
	console.log(totali);
}

function kuJemi(){
	var text = document.getElementById("klikuar");
	console.log(text);
}

/* ===== Lection three ===== */

var arrayOne = [];
var testOne = 10;
arrayOne.push(testOne);
var testTwo = "I am a string";
arrayOne.push(testTwo);
console.log(arrayOne);


function gjejPershendetjen() {
  var greeting;
  var time = new Date().getHours();
  if (time < 10) {
    greeting = "Good morning";
  } else if (time < 20) {
    greeting = "Good day";
  } else {
    greeting = "Good evening";
  }
  document.getElementById("pershendetja").innerHTML = greeting;
}

function gjejDiten() {
	var day;
	switch (new Date().getDay()) {
	  case 0:
		day = "Sunday";
		break;
	  case 1:
		day = "Monday";
		break;
	  case 2:
		day = "Tuesday";
		break;
	  case 3:
		day = "Wednesday";
		break;
	  case 4:
		day = "Thursday";
		break;
	  case 5:
		day = "Friday";
		break;
	  case  6:
		day = "Saturday";
	}
	document.getElementById("dita").innerHTML = "Today is " + day;
}

/* ===== Lection 4 ===== */

function getExactDate(){
	var d = new Date();
	d.setFullYear(2019);
	document.getElementById("dita").innerHTML = d;
}

/* Gjetja e Pi */ 
console.log(Math.PI);

/* Gjetja e 8-es ne katror */
var numer = 8;
console.log(8*8);

/* Gjetj e 8-es ne fuqi te 5 */
var numer = 8;
console.log(Math.pow(8,5));

/* Rrenja katrore */
console.log(Math.sqrt(81));

/* Vlera absolute */
console.log(Math.abs(-3.6));

/* Perafrim */
console.log(Math.ceil(5.4));
console.log(Math.floor(4.7));

/* Gjen minimumin dhe maksimumin nga nje array me numra */
console.log(Math.min(0,150,34,10,5));
console.log(Math.max(0,150,34,10,5));

/* Na kthen nje numer rastesor */
console.log(Math.random());
console.log(Math.floor(Math.random()*100));

/* Gjetja e nje elementin rastesor */
var tabelaJone = [3,4,78,12,99];

var value = tabelaJone[Math.floor(Math.random()*tabelaJone.length)];
console.log(value);

/* If Else ternar */
function gjejMoshen(){
	var age, voteable;
	age = document.getElementById("age").value;
	voteable = (age < 18) ? "Pa të drejtë vote!":(age > 90)? "Ju keni nderruar jete":"Mund të votoni";
	document.getElementById("result").innerHTML = voteable + "!";
}

/*
if(age<18){                      (age < 18)?console.log("Votoni")
	console.log("Votoni");
}else{							 :console.log("Nuk votoni");
	console.log("Nuk votoni");
}*/


/* Konkatenimi */
var vota = "PD";
var vota2 = "PS";
var test3 = "Ska shance!";

console.log(vota +" vs "+ vota2 + " result = " + test3);

/* Cikli for */
function shfaqMakinat(){
	var cars = ["BMW", "VOLVO", "FORD", "PORSCE", "FERRARI", "MERCEDES"];
	var text = "";
	var i;
	for(i=0; i<cars.length; i++){
		text += cars[i] + "</br>";
	}
	document.getElementById("makinat").innerHTML = text;
}









