<?php 
  session_start();
?>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Web Design Course</title>

  <!-- Bootstrap Core CSS -->
  <link href="css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom Fonts -->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
  <!--<link href="vendor/simple-line-icons/css/simple-line-icons.css" rel="stylesheet">-->
  
  <!-- imported style for the slider -->
  <link href="css/full-slider.css" rel="stylesheet">
  <!-- imported style for the zoom effect images -->
  <link href="css/style.css" rel="stylesheet">

</head>
<?php echo "Finally some good material"; ?>
<body id="page-top">