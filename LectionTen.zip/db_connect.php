<?php

$servername = "localhost";
$username = "root";
$password ="";
$databasa = "kursiwebdesign";

//Krijimi i conncection
$conn = new mysqli($servername, $username, $password, $databasa);

//Check connections
if(!$conn){
  die("Connection failed" .mysqli_connect_error());
}
