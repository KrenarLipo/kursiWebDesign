<?php

//Lection nine

/*
---- Fjale kyce te php -------
echo , if, else, while, for, foreach , array, isset,
$_POST[], $_GET[]

---- Ciklet for teorikisht -----
for(parameter1, parameter2, parameter3)

parameter1 qe zakonisht eshte i ose j
for($i=0; $i<sizeof($makina); $i++){
}

----- llojet e variablave ne php ----
int => numrat natyror
float => numrat me presje
string => shkrimet ose karakteret
array => tabela me element

*/

$tree = [3.1444, 1.2344, "test"];
echo "<pre>";
print_r($tree);
echo"</pre>";

$makina = array();

$mesim = "Mesimi i ATC";
$mesimVazhdim = "Eshte kryesisht praktike";

echo $mesim." ".$mesimVazhdim;

/* evidentimi i llojit te variablit */
$z = [59888, "56666", 6969, 123435];
print_r($z);

/* ===== ciklet for ==== */
echo "<h4>Kemi marre te dhenat nga tabela e makinave!</h4>";
$array = ["Benz", "Golf", "Volvo"];

for($i=0; $i<sizeof($array); $i++){
    echo "<br>".$array[$i]."<br>";
}

/*
    while(kusht) {
      //veprime te caktuara
  }
*/


$x = 1;

while($x <= 5) {
  echo "Numri eshte: $x <br>";
  $x++;
}

/*
kushtet if, else
*/

// $mosha = 17;
// if($mosha > 18){
//   echo "Ju mund te votoni!";
// }elseif($mosha < 18){
//   echo "Ju nuk mund te votoni!";
// }else{
//   echo "Sapo fituat te drejten e votimit";
// }

?>
<!-- <style>
   .wrapper {
     width:980px;
     margin:0 auto;
     border:1px solid #787878;
   }
   .leftCol {
     width:50%;
     padding:20px;
     float:left;
   }
   .rightCol {
     width:50%;
     padding:20px;
     float:right;
   }
</style> -->
<hr>
<div class="wrapper">
    <div class="">
      <form method="post">
      Jepni moshen : <input type="number" name="moshaime"/>
      <input type="submit" name="gjejMoshen" value="A votoj?"/>
      </form>
      <?php
      if(isset($_POST['gjejMoshen'])){
         $mosha = $_POST['moshaime'];
         if($mosha > 18){
           echo "Ju mund te votoni!";
         }elseif($mosha < 18){
           echo "Ju nuk mund te votoni!";
         }else{
           echo "Sapo fituat te drejten e votimit";
         }
      }
      ?>
    </div>
    <br>
    <?php
    if(isset($_POST['findResult'])){
      $x = $_POST['fnum'];
      $y = $_POST['snum'];
      $sum = $x + $y;
    }
    ?>
    <div style="padding:20px 10px">
      <form method="post">
        Result <input type="text" value="<?php echo $sum;?>"/>
        <br>
        Enter First Number: <input type="number" name="fnum"/>
        <br>
        Enter Second Number: <input type="number" name="snum"/>
        <input type="submit" name="findResult" value="Add"/>
      </form>
    </div>
</div>
